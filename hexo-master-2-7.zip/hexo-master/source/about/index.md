---
title: about
date: 2019-08-27 01:47:32
---

Hi, I’m a theme for the Hexo blogging framework. I’m particularly great for a personal web page with a simple blog.

![](https://probberechts.github.io/hexo-theme-cactus/cactus-dark/public/assets/cactus.png)

These are my best features:

- I am fully responsive
- I support Disqus integration
- I support Google Analytics
- I have a configurable navigation menu
- I support several code highlighting schemes
- I have Font Awesome icons
- I can live for months without 

Clone or fork my  repo if you like me!