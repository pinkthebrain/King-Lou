---
title: SSH原理与运用（二）：远程操作与端口转发

tags:
- SSH
- LINUX

categories:
- Linux 系列

date: 2019-08-29
---

SSH不仅可以用于远程主机登录，还可以直接在远程主机上执行操作。